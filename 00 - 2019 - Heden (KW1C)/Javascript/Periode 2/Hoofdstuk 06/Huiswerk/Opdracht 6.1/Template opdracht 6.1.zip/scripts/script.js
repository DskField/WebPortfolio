/*
    Opdracht:       Opdracht 6.1
    Auteur:         XXXXX
    Aanmaakdatum:   XX-XX-XX
    Bestandsnaam:   script.js
*/
